﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace full_admine_entrega
{
    public partial class Boleta : Form
    {
        public Boleta()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double valorh;
                using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
                {
                    List<Empleados> resultados = new List<Empleados>();
                    Empleados oempleado = new Empleados();
                    var query = dbo.Empleados.Where(p => p.carnet == textBox1.Text);//obtener datos sean mayores e iguales a la edad digitada

                    foreach (var result in query)
                    {
                        resultados.Add(result);
                    }

                    dataGridView1.DataSource = resultados;
                }

                double sueldo = double.Parse(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[7].Value.ToString());

                string nombre1 = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[2].Value.ToString();
                string nombre2 = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[3].Value.ToString();
                string apellido1 = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[4].Value.ToString();
                string apellido2 = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[9].Value.ToString();
                string cargo = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[5].Value.ToString();
                string departamento = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[6].Value.ToString();
                int idempleado = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value);


                valorh = sueldo / 8;

                txtn1.Text = nombre1;
                txtn2.Text = nombre2;
                txtap1.Text = apellido1;
                txtap2.Text = apellido2;
                txtcargo.Text = cargo;
                txtdepto.Text = departamento;
                txtidmpleado.Text = idempleado.ToString();
                textBox2.Text = Convert.ToString(sueldo);
                txtvalhora.Text = Convert.ToString(valorh);
            }
            catch (Exception ex)
            {

                MessageBox.Show("hay campos importantes que debe llenar");
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Boleta_Load(object sender, EventArgs e)
        {
            //int id = int.Parse(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString());
            label22.Text = DateTime.Now.ToString("dd:MM:yyy");
            refresh2();
            refresh();
            if (textBox1.Text.Trim().Equals(""))
                btncalcular.Enabled = false;
            btmbucar.Enabled = false;

            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {

                var list = dbo.Empleados;
                foreach (var lst in list)
                {
                    listBox1.Items.Add(lst.carnet);
                }
            }
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {

                var list = dbo.Boletas;
                foreach (var lst in list)
                {
                    listBox2.Items.Add(lst.id_Boletas);
                }
            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            btncalcular.Enabled = true;
            btmbucar.Enabled = true;
            textBox1.Text = listBox1.Text;
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            try
            {
                double salario;
                double isss;
                double afp;
                double renta = 0;
                double sueldotot;
                double totext;
                double horas = Convert.ToDouble(numericUpDown2.Value);
                double valhora = Convert.ToDouble(txtvalhora.Text);
                empleado oempleado = new empleado();
                totext = valhora * horas;
                double saldia = Convert.ToDouble(textBox2.Text);
                double diastrab = Convert.ToDouble(numericUpDown1.Value);

                double sueldobruto = oempleado.Obtener_salario(saldia, diastrab);
                txtafp.Text = oempleado.Obtener_afp(sueldobruto).ToString();
                txtsueldobruto.Text = sueldobruto.ToString();
                txtisss.Text = oempleado.obtenriss(sueldobruto).ToString();
                txtextras.Text = totext.ToString();
                salario = sueldobruto;
                isss = Convert.ToDouble(txtisss.Text);
                afp = Convert.ToDouble(txtafp.Text);


                if (sueldobruto <= 236)
                {
                    salario = sueldobruto;
                    renta = 0;

                }
                if (sueldobruto > 236.01 && sueldobruto < 447.62)
                {
                    salario = sueldobruto - (sueldobruto * 0.10);
                    renta = sueldobruto * 0.10;
                }
                if (sueldobruto > 447.62 && sueldobruto < 1019.05)
                {
                    salario = sueldobruto - (sueldobruto * 0.20);
                    renta = sueldobruto * 0.20;

                }
                if (sueldobruto > 1019.05)
                {
                    salario = sueldobruto - (sueldobruto * 0.30);
                    renta = sueldobruto * 0.30;
                }

                txtrent.Text = renta.ToString();
                sueldotot = salario - renta - isss - afp + totext;
                txtsueldotot.Text = Math.Round(sueldotot, 2).ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Un campo importante no esta selecionado o completo " +
                    "comprueve precionando ' BUCAR'");
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            bool encontrado = true;


            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                //fecha = Convert.ToDateTime(dataGridView2.Rows[i].Cells[2].Value.ToString("dd:mm:yy");
                //fecha2 = Convert.ToString(fecha);
                if (dataGridView2.Rows[i].Cells[0].Value.ToString() == txtidmpleado.Text.ToString() && dataGridView2.Rows[i].Cells[2].Value.ToString() == label22.Text)
                {

                    MessageBox.Show("El carnet no se puede repetir");
                    encontrado = false;
                }



            }
            if (encontrado == true)
            {
                try
                {
                    using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
                    {

                        Boletas oboleta = new Boletas();

                        //DateTime hoy;
                        //hoy = DateTime
                        oboleta.id_Empleados = Convert.ToInt32(txtidmpleado.Text);
                        oboleta.sueld_tot = Convert.ToDecimal(txtsueldotot.Text);
                        oboleta.total_dias = Convert.ToDecimal(numericUpDown1.Value);
                        oboleta.total_horaxtras = Convert.ToDecimal(txtextras.Text);
                        oboleta.descuento_ISSS = Convert.ToDecimal(txtisss.Text);
                        oboleta.descuento_AFP = Convert.ToDecimal(txtafp.Text);
                        oboleta.descuento_RENTA = Convert.ToDecimal(txtrent.Text);
                        oboleta.fecha= label22.Text;

                        dbo.Boletas.Add(oboleta);
                        dbo.SaveChanges();
                        MessageBox.Show("los datos se an guardado correctamente");
                       

                           
                       
                        refresh();

                        refresh2();


                    }
                    using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
                    {
                        listBox2.Items.Clear();
                        var list = dbo.Boletas;
                        foreach (var lst in list)
                        {
                            listBox2.Items.Add(lst.id_Boletas);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("los datos no se an guardado");
                }



            }
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {

                var list = dbo.Boletas;
                foreach (var lst in list)
                {
                    listBox2.Items.Add(lst.id_Boletas);
                }
            }

        }
        private void refresh2()
        {
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {
                var list = from d in dbo.Boletas
                           where d.fecha == label22.Text
                           join carnt in dbo.Empleados
                             on d.id_Empleados equals carnt.id_empleado
                           select new { d.id_Boletas, d.id_Empleados, d.sueld_tot, carnt.carnet };
                dataGridView3.DataSource = list.ToList();
            }

        }
        private void refresh()
        {
            //este procedimento genera la carga en union de dos tablas en linq
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {
                var list = from emp in dbo.Empleados

                           join bol in dbo.Boletas
                                on emp.id_empleado equals bol.id_Empleados

                           select new { emp.id_empleado, emp.carnet, bol.fecha };

                dataGridView2.DataSource = list.ToList();
            }



        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {//PENDIENTE ELIMIAR SUPERSU
            try
            {
                using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
                {
                    int id_bol;
                    id_bol = int.Parse(listBox2.Text);
                    Boletas ouser = dbo.Boletas.Where(d => d.id_Boletas == id_bol).First();

                    dbo.Boletas.Remove(ouser);
                    dbo.SaveChanges();

                    refresh();
                    refresh2();


                }
                using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
                {

                    var list = dbo.Boletas;
                    foreach (var lst in list)
                    {
                        listBox2.Items.Add(lst.id_Boletas);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex+"el sistema presenta un error");
            }
         
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
          
            this.Hide();
        }
    }
}

