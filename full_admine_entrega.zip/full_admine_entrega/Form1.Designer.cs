﻿namespace full_admine_entrega
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtpasss = new System.Windows.Forms.TextBox();
            this.txtuser = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.botoncircular2 = new full_admine_entrega.botoncircular();
            this.botoncircular1 = new full_admine_entrega.botoncircular();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::full_admine_entrega.Properties.Resources.usermount;
            this.pictureBox1.Location = new System.Drawing.Point(5, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 251);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.botoncircular2);
            this.panel1.Controls.Add(this.txtpasss);
            this.panel1.Controls.Add(this.txtuser);
            this.panel1.Controls.Add(this.botoncircular1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(171, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(287, 266);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // txtpasss
            // 
            this.txtpasss.Location = new System.Drawing.Point(96, 121);
            this.txtpasss.Name = "txtpasss";
            this.txtpasss.Size = new System.Drawing.Size(110, 20);
            this.txtpasss.TabIndex = 6;
            this.txtpasss.UseSystemPasswordChar = true;
            // 
            // txtuser
            // 
            this.txtuser.Location = new System.Drawing.Point(96, 83);
            this.txtuser.Name = "txtuser";
            this.txtuser.Size = new System.Drawing.Size(110, 20);
            this.txtuser.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "CONTRASEÑA";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "USUARIO";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(464, 7);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(65, 108);
            this.listBox1.TabIndex = 2;
            this.listBox1.Visible = false;
            // 
            // botoncircular2
            // 
            this.botoncircular2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.botoncircular2.BackColor = System.Drawing.Color.SlateGray;
            this.botoncircular2.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.botoncircular2.FlatAppearance.BorderSize = 5;
            this.botoncircular2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.botoncircular2.Location = new System.Drawing.Point(141, 180);
            this.botoncircular2.Name = "botoncircular2";
            this.botoncircular2.Size = new System.Drawing.Size(132, 47);
            this.botoncircular2.TabIndex = 7;
            this.botoncircular2.Text = "SALIR";
            this.botoncircular2.UseVisualStyleBackColor = false;
            this.botoncircular2.Click += new System.EventHandler(this.botoncircular2_Click);
            this.botoncircular2.MouseEnter += new System.EventHandler(this.botoncircular2_MouseEnter);
            this.botoncircular2.MouseLeave += new System.EventHandler(this.botoncircular2_MouseLeave);
            // 
            // botoncircular1
            // 
            this.botoncircular1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.botoncircular1.BackColor = System.Drawing.Color.SlateGray;
            this.botoncircular1.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.botoncircular1.FlatAppearance.BorderSize = 5;
            this.botoncircular1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.botoncircular1.Location = new System.Drawing.Point(3, 180);
            this.botoncircular1.Name = "botoncircular1";
            this.botoncircular1.Size = new System.Drawing.Size(132, 47);
            this.botoncircular1.TabIndex = 4;
            this.botoncircular1.Text = "REGISTRARSE";
            this.botoncircular1.UseVisualStyleBackColor = false;
            this.botoncircular1.Click += new System.EventHandler(this.botoncircular1_Click);
            this.botoncircular1.MouseEnter += new System.EventHandler(this.botoncircular1_MouseEnter);
            this.botoncircular1.MouseLeave += new System.EventHandler(this.botoncircular1_MouseLeave);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(543, 322);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Opacity = 0.8D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ENTRADA";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private botoncircular botoncircular1;
        private System.Windows.Forms.TextBox txtpasss;
        private System.Windows.Forms.TextBox txtuser;
        private System.Windows.Forms.ListBox listBox1;
        private botoncircular botoncircular2;
    }
}

