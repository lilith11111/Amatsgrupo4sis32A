﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace full_admine_entrega
{
    public partial class menu_principal : Form
    {
        bool deseable2 = false;
        bool deseable = false;
        public menu_principal()
        {
           
            InitializeComponent();
           
            
        }

        private void botoncircular2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button5.Enabled == false)
            {
                deseable = true;
            }
            if (button5.Enabled == false)
            {
                deseable2 = true;
            }
            Boleta  frm = new Boleta ();

            if (deseable)
            {

                frm.button2.Enabled = false ;
                frm.listBox2.Visible = false;
            }
                 if (deseable2)
            {

                frm.button2.Enabled = false ;
                frm.listBox2.Visible = false;
            }

            frm.Show();
             this.WindowState = FormWindowState.Minimized;
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button5.Enabled == false&&label1 .Enabled ==false )
            {
                deseable = true;
            }
           
          
            CONTROL_EMPLEADOS cp = new CONTROL_EMPLEADOS();
            if (deseable )
            {
              

                cp.btneliminar.Enabled = false;
                cp.btnguardar.Enabled = false;
                cp.btnmodificar.Enabled = false;
                cp.btnguardar.Enabled = false;
                cp.panel1.Enabled = false;
                cp.dtgcarnets.Visible = false;
            }
            

            cp.Show();
               
            this.WindowState = FormWindowState.Minimized;
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            this.button2.BackColor = Color.LightSkyBlue;
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            this.button1.BackColor = Color.LightSkyBlue;
        }

        private void button3_MouseEnter(object sender, EventArgs e)
        {
            this.button3.BackColor = Color.LightSkyBlue;
        }

        private void button4_MouseEnter(object sender, EventArgs e)
        {
            this.button4.BackColor = Color.LightSkyBlue;
        }

        private void button5_MouseEnter(object sender, EventArgs e)
        {
            this.button5.BackColor = Color.LightSkyBlue;
        }

        private void button6_MouseEnter(object sender, EventArgs e)
        {
        this.button6.BackColor = Color.LightSkyBlue;





        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            this.button1.BackColor = Color.LightSlateGray ;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            this.button2.BackColor = Color.LightSlateGray ;
        
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            this.button3.BackColor = Color.LightSlateGray;
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {
            this.button4.BackColor = Color.LightSlateGray;
        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {
            this.button5.BackColor = Color.LightSlateGray;
        }

        private void button6_MouseLeave(object sender, EventArgs e)
        {
            this.button6.BackColor = Color.LightSlateGray;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button5.Enabled == false && label1.Enabled == false)
            {
                deseable = true;
            }
            Archivero  frm = new Archivero ();
            if (deseable )
            {
                frm.button4.Enabled = false;
            }
            frm.Show();
           this.WindowState = FormWindowState.Minimized;
        
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Control_Usuarios  frm = new Control_Usuarios ();

            frm.Show();
          this.WindowState = FormWindowState.Minimized;
        

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1  frm = new Form1 ();

            frm.Show();
            this.Hide();
        

        }

        private void menu_principal_Load(object sender, EventArgs e)
        {
            label2.BackColor = Color.Transparent;
            timer1.Start();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString  ();
            label2.BackColor = Color.Transparent;
        }

      
    }
}
