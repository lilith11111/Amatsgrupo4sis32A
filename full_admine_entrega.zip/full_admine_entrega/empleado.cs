﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace full_admine_entrega
{
    class empleado
    {

        //private string _nombre1;
        //private string _apellido1;
        //private string _apelldo2;
        //private string _carnet;
        //private string _cargo;
        //private string _telefono;
        //private string _departamento;
        //private double _salariopordia;
        //private string _nombre2;
        //private double _diastrabaja;

        //public empleado(string carnet, string nombre1, string nombre2, string apellido1, string cargo, string departamento, double salariopordia, string telefono, string  apellido2 )
        //{
           
        //     _nombre1 = nombre1;
        //    _nombre2 = nombre2;
        //    _apellido1 = apellido1;
        //    _apelldo2 = apellido2;
        //    _carnet = carnet;
        //    _cargo = cargo;
        //    _telefono = telefono;
        //    _departamento = departamento;
        //    _salariopordia = salariopordia;
           
        //}

       

        //public string Nombre1 { get => _nombre1; set => _nombre1 = value; }
        //public string Nombre2 { get => _nombre2; set => _nombre2 = value; }
        //public string Apellido1 { get => _apellido1; set => _apellido1 = value; }
        //public string Apelldo2 { get => _apelldo2; set => _apelldo2 = value; }
        //public string Carnet { get => _carnet; set => _carnet = value; }
        //public string Cargo { get => _cargo; set => _cargo = value; }
        //public string Telefono { get => _telefono; set => _telefono = value; }
        //public string Departamento { get => _departamento; set => _departamento = value; }
        //public double Salariopordia { get => _salariopordia; set => _salariopordia = value; }

        //public double Diastrabaja { get => _diastrabaja; set => _diastrabaja = value; }


        public double Obtener_salario(double dias ,double valordia)
        {

            double sueldo_bruto;

            sueldo_bruto = dias * valordia;



            return sueldo_bruto;
        }
        public double obtenriss(double sueldo)
        {
            double isss = 0.075;
            double totiss = sueldo * isss;
            return totiss;
        }

        public double Obtener_afp(double sueldo)
        {
            double afp = 0.0725;
            double totAFP;
            

            totAFP = sueldo * afp;

            return totAFP;
        }



    }
}
