﻿namespace full_admine_entrega
{
    partial class CONTROL_EMPLEADOS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label carnetLabel;
            System.Windows.Forms.Label nombre1Label;
            System.Windows.Forms.Label nombre2Label;
            System.Windows.Forms.Label apellido1Label;
            System.Windows.Forms.Label cargoLabel;
            System.Windows.Forms.Label departamentoLabel;
            System.Windows.Forms.Label salariodiaroLabel;
            System.Windows.Forms.Label telefonoLabel;
            System.Windows.Forms.Label apellido2Label;
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idempleadoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carnetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombre1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombre2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellido1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cargoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departamentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salariodiaroDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellido2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empleadosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.proyectofulloficeDataSet = new full_admine_entrega.proyectofulloficeDataSet();
            this.carnetTextBox = new System.Windows.Forms.TextBox();
            this.nombre1TextBox = new System.Windows.Forms.TextBox();
            this.nombre2TextBox = new System.Windows.Forms.TextBox();
            this.apellido1TextBox = new System.Windows.Forms.TextBox();
            this.cargoComboBox = new System.Windows.Forms.ComboBox();
            this.departamentoComboBox = new System.Windows.Forms.ComboBox();
            this.salariodiaroMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.telefonoTextBox = new System.Windows.Forms.TextBox();
            this.apellido2TextBox = new System.Windows.Forms.TextBox();
            this.btnguardar = new System.Windows.Forms.Button();
            this.btneliminar = new System.Windows.Forms.Button();
            this.btnmodificar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnregresar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dtgcarnets = new System.Windows.Forms.DataGridView();
            this.carnet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empleadosTableAdapter = new full_admine_entrega.proyectofulloficeDataSetTableAdapters.EmpleadosTableAdapter();
            this.tableAdapterManager = new full_admine_entrega.proyectofulloficeDataSetTableAdapters.TableAdapterManager();
            carnetLabel = new System.Windows.Forms.Label();
            nombre1Label = new System.Windows.Forms.Label();
            nombre2Label = new System.Windows.Forms.Label();
            apellido1Label = new System.Windows.Forms.Label();
            cargoLabel = new System.Windows.Forms.Label();
            departamentoLabel = new System.Windows.Forms.Label();
            salariodiaroLabel = new System.Windows.Forms.Label();
            telefonoLabel = new System.Windows.Forms.Label();
            apellido2Label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectofulloficeDataSet)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgcarnets)).BeginInit();
            this.SuspendLayout();
            // 
            // carnetLabel
            // 
            carnetLabel.AutoSize = true;
            carnetLabel.Location = new System.Drawing.Point(24, 205);
            carnetLabel.Name = "carnetLabel";
            carnetLabel.Size = new System.Drawing.Size(40, 13);
            carnetLabel.TabIndex = 3;
            carnetLabel.Text = "carnet:";
            // 
            // nombre1Label
            // 
            nombre1Label.AutoSize = true;
            nombre1Label.Location = new System.Drawing.Point(24, 231);
            nombre1Label.Name = "nombre1Label";
            nombre1Label.Size = new System.Drawing.Size(51, 13);
            nombre1Label.TabIndex = 5;
            nombre1Label.Text = "nombre1:";
            // 
            // nombre2Label
            // 
            nombre2Label.AutoSize = true;
            nombre2Label.Location = new System.Drawing.Point(24, 257);
            nombre2Label.Name = "nombre2Label";
            nombre2Label.Size = new System.Drawing.Size(51, 13);
            nombre2Label.TabIndex = 7;
            nombre2Label.Text = "nombre2:";
            // 
            // apellido1Label
            // 
            apellido1Label.AutoSize = true;
            apellido1Label.Location = new System.Drawing.Point(24, 283);
            apellido1Label.Name = "apellido1Label";
            apellido1Label.Size = new System.Drawing.Size(52, 13);
            apellido1Label.TabIndex = 9;
            apellido1Label.Text = "apellido1:";
            // 
            // cargoLabel
            // 
            cargoLabel.AutoSize = true;
            cargoLabel.Location = new System.Drawing.Point(246, 204);
            cargoLabel.Name = "cargoLabel";
            cargoLabel.Size = new System.Drawing.Size(37, 13);
            cargoLabel.TabIndex = 11;
            cargoLabel.Text = "cargo:";
            // 
            // departamentoLabel
            // 
            departamentoLabel.AutoSize = true;
            departamentoLabel.Location = new System.Drawing.Point(500, 204);
            departamentoLabel.Name = "departamentoLabel";
            departamentoLabel.Size = new System.Drawing.Size(75, 13);
            departamentoLabel.TabIndex = 13;
            departamentoLabel.Text = "departamento:";
            // 
            // salariodiaroLabel
            // 
            salariodiaroLabel.AutoSize = true;
            salariodiaroLabel.Location = new System.Drawing.Point(796, 205);
            salariodiaroLabel.Name = "salariodiaroLabel";
            salariodiaroLabel.Size = new System.Drawing.Size(63, 13);
            salariodiaroLabel.TabIndex = 15;
            salariodiaroLabel.Text = "salariodiaro:";
            // 
            // telefonoLabel
            // 
            telefonoLabel.AutoSize = true;
            telefonoLabel.Location = new System.Drawing.Point(796, 227);
            telefonoLabel.Name = "telefonoLabel";
            telefonoLabel.Size = new System.Drawing.Size(48, 13);
            telefonoLabel.TabIndex = 17;
            telefonoLabel.Text = "telefono:";
            // 
            // apellido2Label
            // 
            apellido2Label.AutoSize = true;
            apellido2Label.Location = new System.Drawing.Point(24, 309);
            apellido2Label.Name = "apellido2Label";
            apellido2Label.Size = new System.Drawing.Size(52, 13);
            apellido2Label.TabIndex = 19;
            apellido2Label.Text = "apellido2:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idempleadoDataGridViewTextBoxColumn,
            this.carnetDataGridViewTextBoxColumn,
            this.nombre1DataGridViewTextBoxColumn,
            this.nombre2DataGridViewTextBoxColumn,
            this.apellido1DataGridViewTextBoxColumn,
            this.cargoDataGridViewTextBoxColumn,
            this.departamentoDataGridViewTextBoxColumn,
            this.salariodiaroDataGridViewTextBoxColumn,
            this.telefonoDataGridViewTextBoxColumn,
            this.apellido2DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.empleadosBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(2, 1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(1029, 188);
            this.dataGridView1.TabIndex = 0;
            // 
            // idempleadoDataGridViewTextBoxColumn
            // 
            this.idempleadoDataGridViewTextBoxColumn.DataPropertyName = "id_empleado";
            this.idempleadoDataGridViewTextBoxColumn.HeaderText = "id_empleado";
            this.idempleadoDataGridViewTextBoxColumn.Name = "idempleadoDataGridViewTextBoxColumn";
            this.idempleadoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // carnetDataGridViewTextBoxColumn
            // 
            this.carnetDataGridViewTextBoxColumn.DataPropertyName = "carnet";
            this.carnetDataGridViewTextBoxColumn.HeaderText = "carnet";
            this.carnetDataGridViewTextBoxColumn.Name = "carnetDataGridViewTextBoxColumn";
            this.carnetDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombre1DataGridViewTextBoxColumn
            // 
            this.nombre1DataGridViewTextBoxColumn.DataPropertyName = "nombre1";
            this.nombre1DataGridViewTextBoxColumn.HeaderText = "nombre1";
            this.nombre1DataGridViewTextBoxColumn.Name = "nombre1DataGridViewTextBoxColumn";
            this.nombre1DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombre2DataGridViewTextBoxColumn
            // 
            this.nombre2DataGridViewTextBoxColumn.DataPropertyName = "nombre2";
            this.nombre2DataGridViewTextBoxColumn.HeaderText = "nombre2";
            this.nombre2DataGridViewTextBoxColumn.Name = "nombre2DataGridViewTextBoxColumn";
            this.nombre2DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // apellido1DataGridViewTextBoxColumn
            // 
            this.apellido1DataGridViewTextBoxColumn.DataPropertyName = "apellido1";
            this.apellido1DataGridViewTextBoxColumn.HeaderText = "apellido1";
            this.apellido1DataGridViewTextBoxColumn.Name = "apellido1DataGridViewTextBoxColumn";
            this.apellido1DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cargoDataGridViewTextBoxColumn
            // 
            this.cargoDataGridViewTextBoxColumn.DataPropertyName = "cargo";
            this.cargoDataGridViewTextBoxColumn.HeaderText = "cargo";
            this.cargoDataGridViewTextBoxColumn.Name = "cargoDataGridViewTextBoxColumn";
            this.cargoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // departamentoDataGridViewTextBoxColumn
            // 
            this.departamentoDataGridViewTextBoxColumn.DataPropertyName = "departamento";
            this.departamentoDataGridViewTextBoxColumn.HeaderText = "departamento";
            this.departamentoDataGridViewTextBoxColumn.Name = "departamentoDataGridViewTextBoxColumn";
            this.departamentoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // salariodiaroDataGridViewTextBoxColumn
            // 
            this.salariodiaroDataGridViewTextBoxColumn.DataPropertyName = "salariodiaro";
            this.salariodiaroDataGridViewTextBoxColumn.HeaderText = "salariodiaro";
            this.salariodiaroDataGridViewTextBoxColumn.Name = "salariodiaroDataGridViewTextBoxColumn";
            this.salariodiaroDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // telefonoDataGridViewTextBoxColumn
            // 
            this.telefonoDataGridViewTextBoxColumn.DataPropertyName = "telefono";
            this.telefonoDataGridViewTextBoxColumn.HeaderText = "telefono";
            this.telefonoDataGridViewTextBoxColumn.Name = "telefonoDataGridViewTextBoxColumn";
            this.telefonoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // apellido2DataGridViewTextBoxColumn
            // 
            this.apellido2DataGridViewTextBoxColumn.DataPropertyName = "apellido2";
            this.apellido2DataGridViewTextBoxColumn.HeaderText = "apellido2";
            this.apellido2DataGridViewTextBoxColumn.Name = "apellido2DataGridViewTextBoxColumn";
            this.apellido2DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // empleadosBindingSource
            // 
            this.empleadosBindingSource.DataMember = "Empleados";
            this.empleadosBindingSource.DataSource = this.proyectofulloficeDataSet;
            // 
            // proyectofulloficeDataSet
            // 
            this.proyectofulloficeDataSet.DataSetName = "proyectofulloficeDataSet";
            this.proyectofulloficeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // carnetTextBox
            // 
            this.carnetTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.empleadosBindingSource, "carnet", true));
            this.carnetTextBox.Location = new System.Drawing.Point(105, 202);
            this.carnetTextBox.Name = "carnetTextBox";
            this.carnetTextBox.Size = new System.Drawing.Size(121, 20);
            this.carnetTextBox.TabIndex = 4;
            // 
            // nombre1TextBox
            // 
            this.nombre1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.empleadosBindingSource, "nombre1", true));
            this.nombre1TextBox.Location = new System.Drawing.Point(105, 228);
            this.nombre1TextBox.Name = "nombre1TextBox";
            this.nombre1TextBox.Size = new System.Drawing.Size(121, 20);
            this.nombre1TextBox.TabIndex = 6;
            // 
            // nombre2TextBox
            // 
            this.nombre2TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.empleadosBindingSource, "nombre2", true));
            this.nombre2TextBox.Location = new System.Drawing.Point(105, 254);
            this.nombre2TextBox.Name = "nombre2TextBox";
            this.nombre2TextBox.Size = new System.Drawing.Size(121, 20);
            this.nombre2TextBox.TabIndex = 8;
            // 
            // apellido1TextBox
            // 
            this.apellido1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.empleadosBindingSource, "apellido1", true));
            this.apellido1TextBox.Location = new System.Drawing.Point(105, 280);
            this.apellido1TextBox.Name = "apellido1TextBox";
            this.apellido1TextBox.Size = new System.Drawing.Size(121, 20);
            this.apellido1TextBox.TabIndex = 10;
            // 
            // cargoComboBox
            // 
            this.cargoComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.empleadosBindingSource, "cargo", true));
            this.cargoComboBox.FormattingEnabled = true;
            this.cargoComboBox.Items.AddRange(new object[] {
            "SUPERVISOR",
            "OPERADOR"});
            this.cargoComboBox.Location = new System.Drawing.Point(327, 201);
            this.cargoComboBox.Name = "cargoComboBox";
            this.cargoComboBox.Size = new System.Drawing.Size(121, 21);
            this.cargoComboBox.TabIndex = 12;
            // 
            // departamentoComboBox
            // 
            this.departamentoComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.empleadosBindingSource, "departamento", true));
            this.departamentoComboBox.FormattingEnabled = true;
            this.departamentoComboBox.Items.AddRange(new object[] {
            "OPERACIONES",
            "ADMINISTRACION",
            "MANTENIMIENTO"});
            this.departamentoComboBox.Location = new System.Drawing.Point(607, 201);
            this.departamentoComboBox.Name = "departamentoComboBox";
            this.departamentoComboBox.Size = new System.Drawing.Size(121, 21);
            this.departamentoComboBox.TabIndex = 14;
            // 
            // salariodiaroMaskedTextBox
            // 
            this.salariodiaroMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.empleadosBindingSource, "salariodiaro", true));
            this.salariodiaroMaskedTextBox.Location = new System.Drawing.Point(877, 198);
            this.salariodiaroMaskedTextBox.Name = "salariodiaroMaskedTextBox";
            this.salariodiaroMaskedTextBox.Size = new System.Drawing.Size(121, 20);
            this.salariodiaroMaskedTextBox.TabIndex = 16;
            // 
            // telefonoTextBox
            // 
            this.telefonoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.empleadosBindingSource, "telefono", true));
            this.telefonoTextBox.Location = new System.Drawing.Point(877, 224);
            this.telefonoTextBox.Name = "telefonoTextBox";
            this.telefonoTextBox.Size = new System.Drawing.Size(121, 20);
            this.telefonoTextBox.TabIndex = 18;
            // 
            // apellido2TextBox
            // 
            this.apellido2TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.empleadosBindingSource, "apellido2", true));
            this.apellido2TextBox.Location = new System.Drawing.Point(105, 306);
            this.apellido2TextBox.Name = "apellido2TextBox";
            this.apellido2TextBox.Size = new System.Drawing.Size(121, 20);
            this.apellido2TextBox.TabIndex = 20;
            // 
            // btnguardar
            // 
            this.btnguardar.Location = new System.Drawing.Point(24, 18);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(75, 34);
            this.btnguardar.TabIndex = 21;
            this.btnguardar.Text = "GUARDAR";
            this.btnguardar.UseVisualStyleBackColor = true;
            this.btnguardar.Click += new System.EventHandler(this.btnguardar_Click);
            // 
            // btneliminar
            // 
            this.btneliminar.Location = new System.Drawing.Point(157, 18);
            this.btneliminar.Name = "btneliminar";
            this.btneliminar.Size = new System.Drawing.Size(75, 34);
            this.btneliminar.TabIndex = 22;
            this.btneliminar.Text = "ELIMINAR";
            this.btneliminar.UseVisualStyleBackColor = true;
            this.btneliminar.Click += new System.EventHandler(this.btneliminar_Click);
            // 
            // btnmodificar
            // 
            this.btnmodificar.Location = new System.Drawing.Point(273, 18);
            this.btnmodificar.Name = "btnmodificar";
            this.btnmodificar.Size = new System.Drawing.Size(75, 34);
            this.btnmodificar.TabIndex = 23;
            this.btnmodificar.Text = "MODIFICAR";
            this.btnmodificar.UseVisualStyleBackColor = true;
            this.btnmodificar.Click += new System.EventHandler(this.btnmodificar_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btneliminar);
            this.panel1.Controls.Add(this.btnmodificar);
            this.panel1.Controls.Add(this.btnguardar);
            this.panel1.Location = new System.Drawing.Point(274, 389);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(480, 79);
            this.panel1.TabIndex = 24;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnregresar
            // 
            this.btnregresar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnregresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnregresar.Location = new System.Drawing.Point(825, 407);
            this.btnregresar.Name = "btnregresar";
            this.btnregresar.Size = new System.Drawing.Size(92, 53);
            this.btnregresar.TabIndex = 27;
            this.btnregresar.Text = "SALIR";
            this.btnregresar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnregresar.UseVisualStyleBackColor = false;
            this.btnregresar.Click += new System.EventHandler(this.btnregresar_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(376, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 34);
            this.button1.TabIndex = 24;
            this.button1.Text = "nuevo";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(480, 347);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 24);
            this.label1.TabIndex = 25;
            this.label1.Text = "ACCIONES";
            // 
            // dtgcarnets
            // 
            this.dtgcarnets.AllowUserToAddRows = false;
            this.dtgcarnets.AllowUserToDeleteRows = false;
            this.dtgcarnets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgcarnets.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.carnet});
            this.dtgcarnets.Location = new System.Drawing.Point(27, 332);
            this.dtgcarnets.Name = "dtgcarnets";
            this.dtgcarnets.ReadOnly = true;
            this.dtgcarnets.Size = new System.Drawing.Size(130, 124);
            this.dtgcarnets.TabIndex = 26;
            // 
            // carnet
            // 
            this.carnet.HeaderText = "carnet";
            this.carnet.Name = "carnet";
            this.carnet.ReadOnly = true;
            // 
            // empleadosTableAdapter
            // 
            this.empleadosTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EmpleadosTableAdapter = this.empleadosTableAdapter;
            this.tableAdapterManager.UpdateOrder = full_admine_entrega.proyectofulloficeDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // CONTROL_EMPLEADOS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1051, 496);
            this.Controls.Add(this.btnregresar);
            this.Controls.Add(this.dtgcarnets);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(carnetLabel);
            this.Controls.Add(this.carnetTextBox);
            this.Controls.Add(nombre1Label);
            this.Controls.Add(this.nombre1TextBox);
            this.Controls.Add(nombre2Label);
            this.Controls.Add(this.nombre2TextBox);
            this.Controls.Add(apellido1Label);
            this.Controls.Add(this.apellido1TextBox);
            this.Controls.Add(cargoLabel);
            this.Controls.Add(this.cargoComboBox);
            this.Controls.Add(departamentoLabel);
            this.Controls.Add(this.departamentoComboBox);
            this.Controls.Add(salariodiaroLabel);
            this.Controls.Add(this.salariodiaroMaskedTextBox);
            this.Controls.Add(telefonoLabel);
            this.Controls.Add(this.telefonoTextBox);
            this.Controls.Add(apellido2Label);
            this.Controls.Add(this.apellido2TextBox);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CONTROL_EMPLEADOS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CONTROL_EMPLEADOS";
            this.Load += new System.EventHandler(this.CONTROL_EMPLEADOS_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectofulloficeDataSet)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgcarnets)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private proyectofulloficeDataSet proyectofulloficeDataSet;
        private System.Windows.Forms.BindingSource empleadosBindingSource;
        private proyectofulloficeDataSetTableAdapters.EmpleadosTableAdapter empleadosTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idempleadoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carnetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombre1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombre2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellido1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cargoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departamentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salariodiaroDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellido2DataGridViewTextBoxColumn;
        private proyectofulloficeDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox carnetTextBox;
        private System.Windows.Forms.TextBox nombre1TextBox;
        private System.Windows.Forms.TextBox nombre2TextBox;
        private System.Windows.Forms.TextBox apellido1TextBox;
        private System.Windows.Forms.ComboBox cargoComboBox;
        private System.Windows.Forms.ComboBox departamentoComboBox;
        private System.Windows.Forms.MaskedTextBox salariodiaroMaskedTextBox;
        private System.Windows.Forms.TextBox telefonoTextBox;
        private System.Windows.Forms.TextBox apellido2TextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn carnet;
        internal System.Windows.Forms.Button btnregresar;
        public System.Windows.Forms.Button btnmodificar;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Button btnguardar;
        public System.Windows.Forms.Button btneliminar;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.DataGridView dtgcarnets;
    }
}