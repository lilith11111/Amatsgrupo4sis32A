﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace full_admine_entrega
{
    //todos los using habren y sierran conecciones 
    // dbo es el acceso al entiti  que recoje la base de datos y la cadena de coneccion
    public partial class Control_Usuarios : Form
    {
        //carga lso datos y los actualiza 
        public void cargar()
        {
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {
                var listar =
                   from Empleadosuper in dbo.Empleadosuper select Empleadosuper;
                dataGridView1.DataSource = listar.ToList();
                dataGridView1.ScrollBars = ScrollBars.Vertical; 
                var lst = dbo.Empleados;
                foreach (var list in lst )
                {
                    listBox1.Items.Add(list.id_empleado + "          " + list.nombre1+"    " );
                }
            }
        }
        public Control_Usuarios()
        {
           
                InitializeComponent();
        }

        private void Control_Usuarios_Load(object sender, EventArgs e)
        {
            cargar();
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {try
            {
                using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
                {
                    Empleadosuper Oempleadosuper = new Empleadosuper ();
                   Oempleadosuper.usuario = txtusuario.Text;
                    Oempleadosuper.contraseña = txtcontrasena.Text;
                    Oempleadosuper.nivel = nudnivel.Value.ToString();

                    Oempleadosuper.id_Empleados = int.Parse(txtidempleado.Text);
                    dbo.Empleadosuper.Add(Oempleadosuper);
                    dbo.SaveChanges();

                   



                }
                    

            }
            catch (Exception  ex)
            {
                MessageBox.Show( "=========================" +
                    "" +
                    "" +
                    "los datos ingresados an sido incorrectos,tome en cuenta los empleados, o el sistema presenta problemas");
                
                
            }

        }

        private void dataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            MessageBox.Show("no se cargan mas datos");
        }

        private void btnactualizar_Click(object sender, EventArgs e)
        {
            try
            {
                using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
                {
                    Empleadosuper ouser = dbo.Empleadosuper.Where(d => d.usuario == txtusuario.Text).First();

                    dbo.Empleadosuper.Remove(ouser);
                    dbo.SaveChanges();

                  


                }
            }
            catch(Exception  ex )
        
            {
                MessageBox.Show("=========================" +
                   "" +
                   "" +
                   "No se an podido eliminar datos, o el sistema presenta problemas");


            }
        }

        private void Button4_Click(object sender, EventArgs e)
        {

        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Hide();

            menu_principal  frm = new menu_principal ();

            frm.Show();
        }
    }
}
