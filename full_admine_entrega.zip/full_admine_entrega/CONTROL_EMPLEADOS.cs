﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace full_admine_entrega
{
    public partial class CONTROL_EMPLEADOS : Form
    {
       
        
      
        public CONTROL_EMPLEADOS()
        {
            
            InitializeComponent();
           

        }

        private void CONTROL_EMPLEADOS_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'proyectofulloficeDataSet.Empleados' table. You can move, or remove it, as needed.
            this.empleadosTableAdapter.Fill(this.proyectofulloficeDataSet.Empleados);
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {

                var list = dbo.Empleados;
                foreach (var lst in list)
                {
                    dtgcarnets.Rows.Add(lst.carnet);
                }
            }
           
        }

        private void btnguardar_Click(object sender, EventArgs e)
        {
            dtgcarnets.Rows.Clear();
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {

                var list = dbo.Empleados;
                foreach (var lst in list)
                {
                    dtgcarnets.Rows.Add(lst.carnet);
                }
            }

            try
            {
                bool encontrado = false ;
                for (int i = 0;i< dtgcarnets.RowCount  ;i++  )
                {
                    if (dtgcarnets .Rows[i].Cells[0].Value .ToString ()==carnetTextBox.Text  )
                    {

                        MessageBox.Show("El carnet no se puede repetir");
                        encontrado = true;
                    }
                   
                    

                }
                if (encontrado != true)
                {
                    this.empleadosTableAdapter.insertarEmpleados(carnetTextBox.Text, nombre1TextBox.Text, nombre2TextBox.Text, apellido1TextBox.Text, cargoComboBox.Text, departamentoComboBox.Text, decimal.Parse(salariodiaroMaskedTextBox.Text), telefonoTextBox.Text, apellido2TextBox.Text);
                    this.empleadosTableAdapter.Fill(this.proyectofulloficeDataSet.Empleados);
                    MessageBox.Show("Datos Guardaron correctamente");
                }
              
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex + "        " +
                   
                    "-------------------------------------" +
                    " ha ocurrido un error en el sistema");
            }

        }

        private void btneliminar_Click(object sender, EventArgs e)

        {
            dtgcarnets.Rows.Clear();

            try
            {
                this.empleadosTableAdapter.eliminarempleado(carnetTextBox.Text);
                this.empleadosTableAdapter.Fill(this.proyectofulloficeDataSet.Empleados);
                MessageBox.Show("Los datos se eliminaron  correctamente");

            }
           
            catch (Exception ex)
            {

                MessageBox.Show(ex + " ha ocurrido un erro en el sistema consulte al departamneto de informatica");
            }
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {

                var list = dbo.Empleados;
                foreach (var lst in list)
                {
                    dtgcarnets.Rows.Add(lst.carnet);
                }
            }
        }

        private void btnmodificar_Click(object sender, EventArgs e)
        {
            dtgcarnets.Rows.Clear();
            try
            {
                this.empleadosTableAdapter.actualizarEmpleado(carnetTextBox.Text, nombre1TextBox.Text, nombre2TextBox.Text, apellido1TextBox.Text, cargoComboBox.Text, departamentoComboBox.Text, decimal.Parse(salariodiaroMaskedTextBox.Text), telefonoTextBox.Text, apellido2TextBox.Text, carnetTextBox.Text);
                this.empleadosTableAdapter.Fill(this.proyectofulloficeDataSet.Empleados);
                MessageBox.Show("Datos modificados correctamente");
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex + " ha ocurrido un erro en el sistema consulte al departamento informatica");
            }
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {

                var list = dbo.Empleados;
                foreach (var lst in list)
                {
                    dtgcarnets.Rows.Add(lst.carnet);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var contorl in this.Controls )
            {
                foreach (Control ctrl in this.Controls)
                {
                    if (ctrl is TextBox ||ctrl is MaskedTextBox )
                    {
                        ctrl.Text = "";
                    }
                }
            }
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Hide();

            //menu_principal frm = new menu_principal();
            //frm.WindowState = FormWindowState.Maximized;
          

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
