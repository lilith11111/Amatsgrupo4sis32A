﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
namespace full_admine_entrega
{
   
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {
                var lst = dbo.Empleadosuper;
                foreach (var list in lst)
                {
                    listBox1.Items.Add(list.usuario);
                }
            }

           
        }

        private void botoncircular1_MouseEnter(object sender, EventArgs e)
        {//ESTE ES EL EVNTO HOVER
            this.botoncircular1.BackColor = Color.LightSkyBlue;
        
        }

        private void botoncircular1_MouseLeave(object sender, EventArgs e)
        {
            //ESTE ES EL EVNTO HOVER
            this.botoncircular1.BackColor = Color.LightSlateGray;
        }

        private void botoncircular1_Click(object sender, EventArgs e)
        {
            string usuario;
            string password;
            
            password =txtpasss .Text ;
            usuario =txtuser .Text ;

            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {

               

                var list2 = from d in dbo.Empleadosuper 
                            where d.contraseña == password && d.usuario == usuario && d.nivel == "1"
                            select d;



              
                if (list2.Count() > 0)
                {
                    MessageBox.Show("Bienvenido office ");
                    menu_principal frm = new menu_principal();
                    frm.button5 .Enabled = false;
                    frm.label1.Enabled = false;
                    frm.Show();
                    this.Hide();


                }
                var list3 = from d in dbo.Empleadosuper 
                            where d.contraseña == password && d.usuario == usuario && d.nivel == "2"
                            select d;

                var list4 = from d in dbo.Empleadosuper
                            where d.contraseña == password && d.usuario == usuario && d.nivel == "3"
                            select d;




                if (list3.Count() > 0)
                {
                    MessageBox.Show("Bienvenido admin");
                    menu_principal frm = new menu_principal();
                    frm.button5.Enabled = false;

                    frm.Show();
                    this.Hide();

                }
                if (list4.Count() > 0)
                {
                    MessageBox.Show("Bienvenido superus");
                    menu_principal frm = new menu_principal();
                 

                    frm.Show();
                    this.Hide();

                }
                if (list2.Count() == 0 && list3.Count() == 0 && list4.Count()==0)
                {
                    MessageBox.Show("Datos Ingresados incorrectos");
                    txtuser.Clear();
                    txtpasss.Clear();

                }
                   
            }


            }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void botoncircular2_Click(object sender, EventArgs e)
        {
            this.Close ();
        }

        private void botoncircular2_MouseLeave(object sender, EventArgs e)
        {
            this.botoncircular2.BackColor = Color.LightSlateGray;
        }

        private void botoncircular2_MouseEnter(object sender, EventArgs e)
        {
            this.botoncircular2.BackColor = Color.LightSkyBlue;
        
        }




        
    }
}
