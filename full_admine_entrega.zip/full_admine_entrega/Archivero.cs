﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;//LIBRERIAS NESESARIAS PARA QUE FUNCIONE STREAM
using System.Diagnostics;//LIBRERI PARA PROCESS .STAR QUE ARRANCA LA APLICACION DEFAULT
namespace full_admine_entrega
{
    public partial class Archivero : Form
    {
        public Archivero()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (txtnombre .Text .Trim ().Equals ("")||txtruta .Text .Trim ().Equals ("")||maskedTextBox1 .Text.Trim().Equals("")||txtfecha .Text.Trim().Equals(""))
            {

                MessageBox.Show("Campos vacios obligatorios");

                    return;
            }


            byte[] file = null;
            Stream mystream = openFileDialog1.OpenFile();
            using (MemoryStream ms = new MemoryStream())
            {
                mystream.CopyTo(ms);
                file = ms.ToArray();

            }
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {
                try
                {
                    Archivos_Emp Oarchivo = new Archivos_Emp();
                    Oarchivo.nombre = txtnombre.Text.Trim() ;
                    Oarchivo.nombreoriginal = openFileDialog1.SafeFileName;
                    Oarchivo.doc = file;
                    Oarchivo.fecha =Convert .ToDateTime ( txtfecha.Text);
                    Oarchivo.id_Empleados = int.Parse(maskedTextBox1.Text);
                    dbo.Archivos_Emp.Add(Oarchivo);
                    dbo.SaveChanges();

                    refresh();
                }
                catch(Exception ex)
                {
                    MessageBox.Show("los datos no se an podido guardar en la base de datos");
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Todos los archivos(*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtruta.Text = openFileDialog1.FileName;
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            txtfecha.Text = dateTimePicker1.Text;

        }
        private void  refresh()
        {
            using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
            {
                var list = from d in dbo.Archivos_Emp
                           select new { d.id_Archivos, d.nombre ,d.id_Empleados ,d.fecha,d.nombreoriginal  };
                dataGridView1.DataSource = list.ToList();
            }

        }

        private void Archivero_Load(object sender, EventArgs e)
        {
            refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if ( dataGridView1 .Rows .Count >0)
            {
                int id = int.Parse(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString());
                using (proyectofulloficeEntities2 dbo = new proyectofulloficeEntities2())
                {

                    var oarchivo = dbo.Archivos_Emp.Find(id);
                    string path = AppDomain.CurrentDomain.BaseDirectory;
                    string folder = path + "/temp/";
                    string fullpath = folder + oarchivo.nombreoriginal ;
                   
                    try
                    {
                        if (!Directory.Exists(folder))

                            Directory.CreateDirectory(folder);

                        if (File.Exists(fullpath))
                            //Directory.Delete(fullpath);

                        File.WriteAllBytes(fullpath, oarchivo.doc);
                        Process.Start(fullpath);
                    }
                   catch (Exception ex)
                    {
                        MessageBox.Show(ex + "soy el error");
                    }

                    
                }
            }
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Hide();

           
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
